export default function Sidebar() {
  return (
    <div className="sidebar">
      <h2>Sidebar</h2>
      <p>This is the sidebar</p>
    </div>
  );
}
